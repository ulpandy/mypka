// This is an abstract class called 'Computer' which serves as a blueprint for computer objects.
public abstract class Computer {

    // These are abstract methods that need to be implemented by any subclass of 'Computer'.
    // They define how to get the RAM, HDD, and CPU information for a computer.
    public abstract String getRAM();
    public abstract String getHDD();
    public abstract String getCPU();

    // This is the 'toString' method override. It returns a string representation of the computer's configuration.
    @Override
    public String toString(){
        return "RAM= "+this.getRAM()+", HDD="+this.getHDD()+", CPU="+this.getCPU();
    }
}
