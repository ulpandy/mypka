// This is a concrete class 'Server' that extends the abstract class 'Computer'.
public class Server extends Computer {

    // Private instance variables to store the configuration details of the server.
    private String ram;
    private String hdd;
    private String cpu;

    // Constructor to initialize the Server with specific RAM, HDD, and CPU details.
    public Server(String ram, String hdd, String cpu){
        this.ram = ram;
        this.hdd = hdd;
        this.cpu = cpu;
    }

    // Implementation of the 'getRAM' method, as required by the abstract 'Computer' class.
    @Override
    public String getRAM() {
        return this.ram;
    }

    // Implementation of the 'getHDD' method, as required by the abstract 'Computer' class.
    @Override
    public String getHDD() {
        return this.hdd;
    }

    // Implementation of the 'getCPU' method, as required by the abstract 'Computer' class.
    @Override
    public String getCPU() {
        return this.cpu;
    }
}
