// This is the main class of our program.
public class Main {
    public static void main(String[] args) {
        // We create a Computer object called 'pc' using a factory method,
        // and pass in specific configuration details for a PC.
        Computer pc = ComputerFactory.getComputer("pc", "2 GB", "500 GB", "2.4 GHz");

        // We create another Computer object called 'server' using the same factory method,
        // but this time we provide configuration details for a server.
        Computer server = ComputerFactory.getComputer("server", "16 GB", "1 TB", "2.9 GHz");

        // We print out the configuration of the 'pc' and 'server' objects.
        System.out.println("Factory PC Config::" + pc);
        System.out.println("Factory Server Config::" + server);
    }
}
