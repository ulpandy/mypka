// This is a factory class 'ComputerFactory' responsible for creating instances of Computer subclasses (PC or Server).
public class ComputerFactory {

    // This is a static factory method that creates and returns a Computer object based on the specified 'type' and configuration details.
    public static Computer getComputer(String type, String ram, String hdd, String cpu){
        // Check if the 'type' is "PC" (case-insensitive), and if so, create and return a new PC object with the given configuration.
        if("PC".equalsIgnoreCase(type))
            return new PC(ram, hdd, cpu);

            // Check if the 'type' is "Server" (case-insensitive), and if so, create and return a new Server object with the given configuration.
        else if("Server".equalsIgnoreCase(type))
            return new Server(ram, hdd, cpu);

        // If the 'type' is neither "PC" nor "Server", return null to indicate an unsupported or invalid type.
        return null;
    }
}

