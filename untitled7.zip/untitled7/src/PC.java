// This is a concrete class 'PC' that extends the abstract class 'Computer'.
public class PC extends Computer {

    // Private instance variables to store the configuration details of the PC.
    private String ram;
    private String hdd;
    private String cpu;

    // Constructor to initialize the PC with specific RAM, HDD, and CPU details.
    public PC(String ram, String hdd, String cpu){
        this.ram = ram;
        this.hdd = hdd;
        this.cpu = cpu;
    }

    // Implementation of the 'getRAM' method, as required by the abstract 'Computer' class.
    @Override
    public String getRAM() {
        return this.ram;
    }

    // Implementation of the 'getHDD' method, as required by the abstract 'Computer' class.
    @Override
    public String getHDD() {
        return this.hdd;
    }

    // Implementation of the 'getCPU' method, as required by the abstract 'Computer' class.
    @Override
    public String getCPU() {
        return this.cpu;
    }
}
